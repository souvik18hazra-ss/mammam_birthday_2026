# MAMMAM — CHAPTER 23

A responsive, romantic birthday-surprise website built with React, Vite, TypeScript and CSS. It includes an opening gift, birthday reveal, interactive cake/wish, customizable letter, 23-photo gallery with lightbox and favorites, memory timeline, compliment cards, 23 interactive wishes, optional music/video, share controls, and a final surprise.

## Requirements
- Node.js 20 or newer (recommended)
- npm

## Run locally
```bash
npm install
npm run dev
```
Open the local URL shown by Vite.

## Production build
```bash
npm run build
npm run preview
```
The production files are generated in `dist/`.

## Customize the website
Most content lives in `src/config/birthdayConfig.ts`:
- `recipient`, `age`, `title`, `birthdayDate`, and `timezone`
- `opening`, `hero`, `letter`, `signature`, and `finalMessage`
- `theme` colors
- `memories` gallery entries and captions
- `timeline`, `compliments`, and `wishes`
- `music` and `video` settings

The sample text is editable placeholder copy. Replace it with your own words and real memories before sharing.

## Add your 23 photographs
Place your own images in `public/images/memories/` using these exact names:
`photo-01.jpg` through `photo-23.jpg`.

The gallery already contains 23 entries in `src/config/birthdayConfig.ts`. It displays an intentional placeholder until a matching image is added. JPG is the easiest format; WebP is also fine if you update that entry's `src` path. Use compressed images (ideally 300–700 KB each), and choose portrait or landscape images that look good when cropped. Set each entry's `objectPosition` to values such as `center`, `50% 30%`, or `top` to adjust the crop.

To add more photographs, append another object to the `memories` array with a unique `id`, `title`, `caption`, and `src`. The grid and lightbox are generated dynamically from this array.

## Add music
Place a legally obtained audio file at `public/audio/birthday-song.mp3`. The music player starts only after the visitor presses Play. If you do not want music, set `music.enabled` to `false` and remove or hide the player in `src/App.tsx` as desired.

## Add a video
Place your video at `public/videos/mammam-message.mp4`, set `video.enabled` to `true`, and customize `video.src` and optional `video.poster` in the config. The video section is omitted when disabled.

## Change colors and typography
Edit the `theme` values in the configuration and the matching CSS custom properties near the top of `src/styles/globals.css`. Fonts currently load from Google Fonts; fallback fonts are defined for offline use.

## Deployment
### Vercel
1. Push this folder to a GitHub repository.
2. Import the repository into Vercel.
3. Use `npm run build` as the build command and `dist` as the output directory.
4. Deploy and test the published URL on a phone.

### GitHub Pages
The Vite config uses a relative base path (`./`) to help static hosting. Build with `npm run build`, publish the contents of `dist/` using GitHub Pages, and test all assets at the published path.

## Privacy note
This is a static website. Any photos, videos, and audio shipped with the deployed site may be accessible to people who can access the site or asset URLs. Do not add sensitive photos unless you are comfortable with that. The site does not require accounts or collect personal data.

## Before sharing checklist
- [ ] Replace all 23 photo placeholders with your own photos.
- [ ] Personalize captions and timeline entries.
- [ ] Edit the letter and final message so they sound like you.
- [ ] Add music only if you have permission to use it.
- [ ] Test the site on a phone.
- [ ] Test gallery navigation and the final reveal.
- [ ] Run `npm run build` and fix any errors.
- [ ] Share the deployed URL, not a local development URL.
